We were not able to collect any other payloads for the Bouncing Golf APT group.
