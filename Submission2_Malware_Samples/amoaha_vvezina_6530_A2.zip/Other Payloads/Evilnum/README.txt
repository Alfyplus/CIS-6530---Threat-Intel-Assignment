!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Evilnum.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


18558a236e6dc15447c4683d38d4cd5c65331f2469b95b65342a1dcc5e4999fe.lnk
SHA1: ee050a767eaa5227ed40d7a77b7746aea0554ae5
MD5: 48e90ca0f344e1a0445936f2d28ae01f
Original File Name: Unknown
Malware Family/Type: LNK file containing JavaScript
Sample Obtained From: https://bazaar.abuse.ch/sample/18558a236e6dc15447c4683d38d4cd5c65331f2469b95b65342a1dcc5e4999fe/
Source for File Provenance: https://www.welivesecurity.com/2020/07/09/more-evil-deep-look-evilnum-toolset/
Source for File Provenance: https://github.com/eset/malware-ioc/tree/master/evilnum

9666285017da522bc193fdfa89ecec0ebb8f382aed04260f9c3dc6520bcb23b5.lnk
SHA1: a2dbd75dd079594d36509f5ef84a22f869df68cf
MD5: c32820d1eb296d44c56f8430584d9d69
Original File Name: Unknown
Malware Family/Type: LNK file containing JavaScript
Sample Obtained From: https://bazaar.abuse.ch/sample/9666285017da522bc193fdfa89ecec0ebb8f382aed04260f9c3dc6520bcb23b5/
Source for File Provenance: https://www.welivesecurity.com/2020/07/09/more-evil-deep-look-evilnum-toolset/
Source for File Provenance: https://github.com/eset/malware-ioc/tree/master/evilnum
