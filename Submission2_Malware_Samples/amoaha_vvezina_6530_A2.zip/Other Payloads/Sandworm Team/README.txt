!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Sandworm Team.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


052ebc9a518e5ae02bbd1bd3a5a86c3560aefc9313c18d81f6670c3430f1d4d4.xls
SHA1: aa67ca4fb712374f5301d1d2bab0ac66107a4df1
MD5: 97b7577d13cf5e3bf39cbe6d3f0a7732
Original File Name: Unknown
Malware Family/Type: Lure
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2016/2016.01.03 - BlackEnergy by the SSHBearDoor - attacks against Ukrainian news media and electric industry/Samples/
Source for File Provenance: https://www.welivesecurity.com/2016/01/03/blackenergy-sshbeardoor-details-2015-attacks-ukrainian-news-media-electric-industry/

39d04828ab0bba42a0e4cdd53fe1c04e4eef6d7b26d0008bd0d88b06cc316a81.doc
SHA1: 28719979d7ac8038f24ee0c15114c4a463be85fb
MD5: e15b36c2e394d599a8ab352159089dd2
Original File Name: $RR143TB.doc 
Malware Family/Type: Lure
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2016/2016.01.28 - BlackEnergy APT Attacks in Ukraine/Samples/
Source for File Provenance: https://securelist.com/blackenergy-apt-attacks-in-ukraine-employ-spearphishing-with-word-documents/73440/

dd7a9d8d8f550a8091c79f2fb6a7b558062e66af852a612a1885c3d122f2591b.zip
SHA1: c4beecf5e03062aca666bd654e554463d6c3a3a1
MD5: 9e6d6cbf9cfbe7eec97d2814b3e0eb1f
Original File Name: Unknown
Malware Family/Type: Kalambur Backdoor
Sample Obtained From: https://bazaar.abuse.ch/sample/dd7a9d8d8f550a8091c79f2fb6a7b558062e66af852a612a1885c3d122f2591b/
Source for File Provenance: https://blog.eclecticiq.com/sandworm-apt-targets-ukrainian-users-with-trojanized-microsoft-kms-activation-tools-in-cyber-espionage-campaigns
