!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Dragonfly.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


be9521bed1b46f5c7e87dd810c197b79c19b3d2090e3536cbab2705e1e4bc312.php
SHA1: 88374c557d3c96b65de3809fb6d8684758c5a15e
MD5: f3e3e25a822012023c6e81b206711865
Original File Name: ini.php and mysql.php 
Malware Family/Type: wso shell + mailer
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2018/2018.04.23 - Energetic Bear -  attacks on servers/Samples/
Source for File Provenance: https://ics-cert.kaspersky.com/publications/reports/2018/04/23/energetic-bear-crouching-yeti-attacks-on-servers/
