!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Sidewinder.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


1cbec920afe2f978b8f84e0a4e6b757d400aeb96e8c0a221130060b196ece010.docx
SHA1: de25d70ab9da6c1af580932d07bedd17e77a9a29
MD5: 1afb77b2f0ef2e082b37d9ff4b2e7e78
Original File Name: Unknown
Malware Family/Type: Malicious Word document
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2020/2020.12.09 - SideWinder Uses South Asian Issues for Spear Phishing%2C Mobile/Samples/
Source for File Provenance: https://www.trendmicro.com/en_us/research/20/l/sidewinder-leverages-south-asian-territorial-issues-for-spear-ph.html

7238f4e5edbe0e5a2242d8780fb58c47e7d32bf2c4f860c88c511c30675d0857.rtf
SHA1: d6066b94968ba76864f930eda55267549eae7f9c
MD5: e24e51ec170b2341ef90321640fef797
Original File Name: Unknown
Malware Family/Type: CVE-2017-11882
Sample Obtained From: https://bazaar.abuse.ch/sample/7238f4e5edbe0e5a2242d8780fb58c47e7d32bf2c4f860c88c511c30675d0857/
Source for File Provenance: https://www.trendmicro.com/en_us/research/20/l/sidewinder-leverages-south-asian-territorial-issues-for-spear-ph.html
