!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group APT29.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


1c7593078f69f642b3442dc558cddff4347334ed7c96cd096367afd08dca67bc.hta
SHA1: 74dd1d535e675406d45d747a30ffd86e194039c7
MD5: 9e07a9b8dd3ae5e360cfacc20bd1ec38
Original File Name: wine.hta
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/1c7593078f69f642b3442dc558cddff4347334ed7c96cd096367afd08dca67bc
Source for File Provenance: https://www.zscaler.com/blogs/security-research/european-diplomats-targeted-apt29-cozy-bear-wineloader

3739b2eae11c8367b576869b68d502b97676fb68d18cc0045f661fbe354afcb9.pdf
SHA1: f6aad0fbffc4f3bbcdcdbd1deee11b298ef86039
MD5: 6e1b219fc0db106ff3a6e982fb7b9241
Original File Name: wine.pdf
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/3739b2eae11c8367b576869b68d502b97676fb68d18cc0045f661fbe354afcb9/
Source for File Provenance: https://www.zscaler.com/blogs/security-research/european-diplomats-targeted-apt29-cozy-bear-wineloader

653db3b63bb0e8c2db675cd047b737cefebb1c955bd99e7a93899e2144d34358.zip
SHA1: 5a3bd2f12875098bd06b9f5a5a9405d9cf3af837
MD5: a89b9bdf5f28f4380f383ee199401bdc
Original File Name: win.zip
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/653db3b63bb0e8c2db675cd047b737cefebb1c955bd99e7a93899e2144d34358/
Source for File Provenance: https://research.checkpoint.com/2025/apt29-phishing-campaign/
