!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group FIN7.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


2ba6709be053eb456c7fbe0c7e19196fefc7fe93afaea1e008c417aa6faeeeb3.xlsb
SHA1: 34180042eb320e72da7ada351215c3b68e5f1307
MD5: 7248b00b3a6cdc571fd11a6c7ed01801
Original File Name: order.xlsb
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/2ba6709be053eb456c7fbe0c7e19196fefc7fe93afaea1e008c417aa6faeeeb3
Source for File Provenance: https://github.com/RedDrip7/APT_Digital_Weapon/blob/master/FIN7/FIN7_hash.md
Source for File Provenance: https://github.com/StrangerealIntel/CyberThreatIntel/blob/master/Russia/Cybercriminal group/FIN7/16-10-19/Analysis.md

71832696f8efa5ea83ffd5cf0af981ea931297b4679e71990afd6bac350d31fe.doc
SHA1: 895cbed43d27d42e7a021eb7a7f811f58896d8c7
MD5: dc7c07bac0ce9d431f51e2620da93398
Original File Name: Clients-Current_state-062021-0.doc
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/71832696f8efa5ea83ffd5cf0af981ea931297b4679e71990afd6bac350d31fe
Source for File Provenance: https://www.anomali.com/blog/cybercrime-group-fin7-using-windows-11-alpha-themed-docs-to-drop-javascript-backdoor
Source for File Provenance: https://nsfocusglobal.com/apt-retrospection-fin7-uses-windows-11-topics-as-bait-to-do-spear-phishing-attacks/

d9be275feff4b3383821b1483ba93424fb27aa40e138da41a91511193d9538cb.xlsx
SHA1: 4ddc7358f615987bf92ed9192430693db65b097c
MD5: 1ac719c744d22f42e4978e7b55828435
Original File Name: Unknown
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/d9be275feff4b3383821b1483ba93424fb27aa40e138da41a91511193d9538cb
Source for File Provenance: https://openhunting.io/threat-library-detail?data=jssloader
