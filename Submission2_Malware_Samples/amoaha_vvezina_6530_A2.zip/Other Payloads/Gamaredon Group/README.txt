!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Gamaredon Group.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


05f23e5c668c73128b6140b2d7265457ce334072a0b940141a839ec3e7234414.rar
SHA1: 15189e2da0ec0e00d6700674f9adb89859da2985
MD5: 35e7f92d20ec322a7fb5f669761e261e
Original File Name: 9_5_5_433_17.11.2025.rar
Malware Family/Type: CVE-2025-6218
Sample Obtained From: https://bazaar.abuse.ch/sample/05f23e5c668c73128b6140b2d7265457ce334072a0b940141a839ec3e7234414
Source for File Provenance: https://blog.synapticsystems.de/inside-gamaredon-2025-zero-click-espionage-at-scale/

0cebe68cbe06a390acee24c33155bb1d9910d4edcb660d0d235ce2a4e3c643c5.hta
SHA1: 6dd36351ad0a453c93315f6ba0819d6d8c2340b9
MD5: 70a4235b82919949c185adb7b28baff3
Original File Name: Unknown
Malware Family/Type: Unknown
Sample Obtained From: https://bazaar.abuse.ch/sample/0cebe68cbe06a390acee24c33155bb1d9910d4edcb660d0d235ce2a4e3c643c5
Source for File Provenance: https://blog.synapticsystems.de/inside-gamaredon-2025-zero-click-espionage-at-scale/

55ec220d943c45834506bc4d78bfebdf880fc55c986ae247991e8e593fc2f08c.doc
SHA1: 51e0ad738d8f83d52791a058a5b24a85a32d40f9
MD5: 4af2f51ff0a91db064d7c5a5dbcb073e
Original File Name: Додаткова угода до договору по розподілу електричної енергії на 2024 рік 02.01.2024р.doc
Malware Family/Type: Malicious Word Document
Sample Obtained From: https://bazaar.abuse.ch/sample/55ec220d943c45834506bc4d78bfebdf880fc55c986ae247991e8e593fc2f08c
Source for File Provenance: https://www.ibm.com/think/x-force/hive0051-all-in-triple-threat
