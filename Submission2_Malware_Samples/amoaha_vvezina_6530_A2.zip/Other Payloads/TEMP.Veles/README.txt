!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group TEMP.Veles.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


bef59b9a3e00a14956e0cd4a1f3e7524448cbe5d3cc1295d95a15b83a3579c59.zip
SHA1: 1dd89871c4f8eca7a42642bf4c5ec2aa7688fd5c
MD5: 0face841f7b2953e7c29c064d6886523
Original File Name: library.zip
Malware Family/Type: TRITON
Sample Obtained From: https://github.com/MDudek-ICS/TRISIS-TRITON-HATMAN/tree/master/original_samples
Source for File Provenance: https://cloud.google.com/blog/topics/threat-intelligence/attackers-deploy-new-ics-attack-framework-triton/
Source for File Provenance: https://cloud.google.com/blog/topics/threat-intelligence/triton-attribution-russian-government-owned-lab-most-likely-built-tools/
