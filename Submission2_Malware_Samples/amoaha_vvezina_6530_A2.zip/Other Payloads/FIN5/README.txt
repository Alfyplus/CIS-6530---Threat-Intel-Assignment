We were not able to collect any other payloads for the FIN5 APT group.
This is at least in part due to them using stolen legitimate credentials for initial access, bypassing the need for phishing.
