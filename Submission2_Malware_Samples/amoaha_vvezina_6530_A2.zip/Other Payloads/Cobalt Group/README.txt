!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Cobalt Group.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


35ae52d76e551114daad0b6b3947bd263d9499f2af59bdbd6884ff6fbbae2405.txt
SHA1: fdf0213d99a12e3ab57fdf2f235ce7393574c367
MD5: e368365bece9fb5b0bc8de1209bab694
Original File Name: 31385.txt
Malware Family/Type: dll disguised as txt file
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2018/2018.08.30 - Cobalt Group - Double the Infection%2C Double the Fun/Samples/
Source for File Provenance: https://www.netscout.com/blog/asert/double-infection-double-fun

5859a21be4ca9243f6adf70779e6986f518c3748d26c427a385efcd3529d8792.jpg
SHA1: a9fa69915e8c6e8b96c6cd68b94f7220021053cb
MD5: f3bb3e2c03f3976c107de88b43a22655
Original File Name: id02082018.jpg
Malware Family/Type: UPX packed executable disguised as jpg file
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2018/2018.08.30 - Cobalt Group - Double the Infection%2C Double the Fun/Samples/
Source for File Provenance: https://www.netscout.com/blog/asert/double-infection-double-fun

6ca3fc2924214dbf14ba63dde2edb1e5045a405c3370a624c1bb785f1dc0e8ff.doc
SHA1: c565c95765c0493c2918ac0eff80f0a50284ac7b
MD5: 61e3207a3ea674c2ae012f44f2f5618b
Original File Name: Document00591674.doc
Malware Family/Type: Lure
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2018/2018.08.30 - Cobalt Group - Double the Infection%2C Double the Fun/Samples/
Source for File Provenance: https://www.netscout.com/blog/asert/double-infection-double-fun
