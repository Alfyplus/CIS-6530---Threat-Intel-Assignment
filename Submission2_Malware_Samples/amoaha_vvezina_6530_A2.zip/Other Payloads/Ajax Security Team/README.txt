!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Ajax Security Team.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


90ae1358cc770d088655b9ebf6611db9fe29ea991e85a4d04260b81587339fd0
SHA1: 4711f063a0c67fb11c05efdb40424377799efafd
MD5: 4bf2218eb068385ca1bfff8d609c0104
Original File Name: Unknown
Malware Family/Type: Malicious Microsoft document
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2015/2015.11.09 - Rocket Kitten/Samples/
Source for File Provenance: https://blog.checkpoint.com/wp-content/uploads/2015/11/rocket-kitten-report.pdf
Source for File Provenance: https://documents.trendmicro.com/assets/wp/wp-operation-woolen-goldfish.pdf

959b4c2433aa3a021259b310b3b65f1f2697fe72d9ee8787827a7f6c7a193f6f
SHA1: c727b8c43943986a888a0428ae7161ff001bf603
MD5: f68a0a3784a7edfc60ad9333ec209cbf
Original File Name: Unknown
Malware Family/Type: Malicious Microsoft document
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2015/2015.11.09 - Rocket Kitten/Samples/
Source for File Provenance: https://blog.checkpoint.com/wp-content/uploads/2015/11/rocket-kitten-report.pdf
Source for File Provenance: https://documents.trendmicro.com/assets/wp/wp-operation-woolen-goldfish.pdf
