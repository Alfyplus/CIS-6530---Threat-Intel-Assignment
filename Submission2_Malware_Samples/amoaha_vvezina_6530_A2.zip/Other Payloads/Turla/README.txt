!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Turla.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


2299ff9c7e5995333691f3e68373ebbb036aa619acd61cbea6c5210490699bb6.docx
SHA1: d6e6eab05af60a496060d266f144e43f6d5d6ec1
MD5: 6e7991f93c53a58ba63a602b277e07f7
Original File Name: National Day Reception (Dina Mersine Bosio Ambassador’s Secretary).docx
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/2299ff9c7e5995333691f3e68373ebbb036aa619acd61cbea6c5210490699bb6
Source for File Provenance: https://securelist.com/kopiluwak-a-new-javascript-payload-from-turla/77429/

c430ebab4bf827303bc4ad95d40eecc7988bdc17cc139c8f88466bc536755d4e.html
SHA1: 884038cbbfefaeefe992a55f9f949b167430cf7e
MD5: 0fb4042d252d1acc6d3e46fd47445cf6
Original File Name: Unknown
Malware Family/Type: IronPython script disguised as html file, part of IronNetInjector
Sample Obtained From: https://bazaar.abuse.ch/sample/c430ebab4bf827303bc4ad95d40eecc7988bdc17cc139c8f88466bc536755d4e/
Source for File Provenance: https://unit42.paloaltonetworks.com/ironnetinjector/

d2fad779289732d1edf932b62278eb3090eb814d624f2e0a4fbbc613495c55e8.vbs
SHA1: 9cec3972fa35c88de87bd66950e18b3e0a6df77c
MD5: c07a655602adc775b1c2b75dc80df820
Original File Name: Unknown
Malware Family/Type: VBScript
Sample Obtained From: https://bazaar.abuse.ch/sample/d2fad779289732d1edf932b62278eb3090eb814d624f2e0a4fbbc613495c55e8
Source for File Provenance: https://www.welivesecurity.com/en/eset-research/moon-backdoors-lunar-landing-diplomatic-missions
