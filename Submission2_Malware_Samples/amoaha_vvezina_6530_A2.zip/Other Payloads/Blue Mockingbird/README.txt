We were not able to collect any other payloads for the Blue Mockingbird APT group.
This is likely due to them using RCE exploits on public facing servers to gain intial access, bypassing the need for phishing.
