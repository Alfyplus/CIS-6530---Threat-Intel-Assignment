!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group APT28.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


8f4bca3c62268fff0458322d111a511e0bcfba255d5ab78c45973bd293379901.xls
SHA1: a45ab1a9dec488278ee9682735d42d61dfc38b9e
MD5: f8d9b7c864fb7558e8bad4cfb5c8e6ff
Original File Name: testtemp.xls
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/8f4bca3c62268fff0458322d111a511e0bcfba255d5ab78c45973bd293379901/
Source for File Provenance: https://www.splunk.com/en_us/blog/security/notdoor-insights-a-closer-look-at-outlook-macros-and-more.html

ed8f20bbab18b39a67e4db9a03090e5af8dc8ec24fe1ddf3521b3f340a8318c1.docm
SHA1: de037b7e5e93ba1f8f6933d479f1216a9f01ecb2
MD5: eba56e503290204ab2bd77b130b3a1e4
Original File Name: INDICE NEGRO.docm
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/ed8f20bbab18b39a67e4db9a03090e5af8dc8ec24fe1ddf3521b3f340a8318c1/
Source for File Provenance: https://lab52.io/blog/operation-macromaze-new-apt28-campaign-using-basic-tooling-and-legit-infrastructure/
