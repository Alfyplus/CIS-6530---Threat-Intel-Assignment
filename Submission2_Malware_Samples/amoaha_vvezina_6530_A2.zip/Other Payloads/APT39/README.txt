!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group APT39.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


0ee32e3ea3d83da9df6317d7c8c539f0f3622af82ef242d74fdca1e5d4ee427f.docx
SHA1: 1ec6b3e3ba10c07468df40b4707a1d4b86490aed
MD5: 9f7c280b20d021f0a0984d1ad0aeba41
Original File Name: Urban Development Plan.docx
Malware Family/Type: Malicious Word document
Sample Obtained From: https://bazaar.abuse.ch/sample/0ee32e3ea3d83da9df6317d7c8c539f0f3622af82ef242d74fdca1e5d4ee427f/
Source for File Provenance: https://www.ic3.gov/CSA/2020/200917-2.pdf
