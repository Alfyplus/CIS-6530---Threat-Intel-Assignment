!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This folder contains live malware and/or malicious documents.
Do not open or run any of the files unless you know what you are doing.
The password for all encrypted files is "infected".
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CAUTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This folder contains malware and/or malicious documents created/used by the APT group Patchwork.
All files are named their SHA256 hash.
File information, sample source, and references proving provenance can be found below.


2f329a1171d2c6b1471604bf76157b6487c3e59d21bf4a0856e29dc4ba8753cb.lnk
SHA1: 00fdcecc28b62333946610d751aae3eed1c2eb3f
MD5: 8c342a5519400df4044e2ed75ea5a936
Original File Name: Unknown
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/2f329a1171d2c6b1471604bf76157b6487c3e59d21bf4a0856e29dc4ba8753cb/
Source for File Provenance: https://labs.k7computing.com/index.php/breakingdown-of-patchwork-apt/

341f27419becc456b52d6fbe2d223e8598065ac596fa8dec23cc722726a28f62.lnk
SHA1: ed439d668b8b488facb4caba4302c35514cf1a38
MD5: ef1e5823cbce02eb068942ebc39eb308
Original File Name: Unmanned_Vehicle_Systems_Conference_2025_In_Istanbul.lnk
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/341f27419becc456b52d6fbe2d223e8598065ac596fa8dec23cc722726a28f62/
Source for File Provenance: https://arcticwolf.com/resources/blog/dropping-elephant-apt-group-targets-turkish-defense-industry/

5b5b1608e6736c7759b1ecf61e756794cf9ef3bb4752c315527bcc675480b6c6.rtf
SHA1: 021ea88ee2c5a3dd16c7dc2dd703c0850cc18f83
MD5: c82823618b6d13d6540caecb4aef97bb
Original File Name: EOIForm.rtf
Malware Family/Type: Lure
Sample Obtained From: https://bazaar.abuse.ch/sample/5b5b1608e6736c7759b1ecf61e756794cf9ef3bb4752c315527bcc675480b6c6/
Source for File Provenance: https://www.threatdown.com/blog/patchwork-apt-caught-in-its-own-web/

a67220bcf289af6a99a9760c05d197d09502c2119f62762f78523aa7cbc96ef1
SHA1: 97c06906018b57e36145d5a2656f706e07cf9dfa
MD5: 2f800dbee51f6345cec8da1fe5c3d8af
Original File Name: Unknown
Malware Family/Type: Malicious Word document, exploiting CVE-2015-2545 or CVE-2017-0261
Sample Obtained From: https://infocon.org/mirrors/vx underground - 2025 June/APTs/2018/2018.03.07 - Patchwork Continues to Deliver BADNEWS to the Indian Subcontinent/Samples/
Source for File Provenance: https://unit42.paloaltonetworks.com/unit42-patchwork-continues-deliver-badnews-indian-subcontinent/
