#Written by Victor Vezina for CIS*6530 Submission 4

import os
import sys
from sklearn.feature_extraction.text import TfidfVectorizer

#Define global constants
MIN_VALID_FILE_SIZE = 100
DEFAULT_MALWARE_TYPE = "Unknown"
HELP_INFO = '''Valid Arguments:
-i/--input <dir_path>  to set the directory the opcode files are in (Default "Raw Data")
-t/--type <types_path> to set the path to the malware types input file (Default none)
-o/--output <csv_path> to set the path to the output csv file (Default "Processed Data.csv")
-n/--ngram <ngram>     to set the ngram value used when vectorizing (Default 1)'''

#Define global variables and their defaults
opcodeFolder = os.path.abspath("Raw Data")
malwareTypesFile = None
processedDataFile = os.path.abspath("Processed Data.csv")
ngram = (1, 1)

#Print help information and exit the program
def printHelp(code = 0):
	print(HELP_INFO)
	exit(code)

#Parse command line arguments
if len(sys.argv) >= 2:
	#Get the argument at index+1
	def getArg(index, arg):
		if index+1 >= len(sys.argv):
			print('ERROR: No value found after argument "' + arg + '"')
			printHelp(1)
		else:
			return sys.argv[index+1]
	index = 1
	while index < len(sys.argv):
		arg = sys.argv[index]
		if arg == "-h" or arg == "--help":
			printHelp()
		elif arg == "-i" or arg == "--input":
			#Set the opcode directory based on given input
			opcodeFolder = os.path.abspath(getArg(index, arg))

			#Ensure the given path is a valid directory
			if not os.path.isdir(opcodeFolder):
				print('ERROR: "' + opcodeFolder + '" is not a directory')
				printHelp(1)
			print('Set opcode directory to "' + opcodeFolder + '"')
			index += 2
		elif arg == "-t" or arg == "--type":
			#Set the malware type file path based on given input
			malwareTypesFile = os.path.abspath(getArg(index, arg))

			#Ensure the given path is a valid file
			if not os.path.isfile(malwareTypesFile):
				print('ERROR: "' + malwareTypesFile + '" is not a file')
				printHelp(1)
			print('Set malware types file to "' + malwareTypesFile + '"')
			index += 2
		elif arg == "-o" or arg == "--output":
			#Set the output path based on given input
			processedDataFile = os.path.abspath(getArg(index, arg))
			os.makedirs(os.path.dirname(processedDataFile), exist_ok=True)
			print('Set csv file to "' + processedDataFile + '"')
			index += 2
		elif arg == "-n" or arg == "--ngram":
			#Set the n-gram value based on given input
			val = int(getArg(index, arg))
			ngram = (val, val)
			print('Set ngram to ' + str(ngram))
			index += 2
		else:
			print('ERROR: Unknown argument "' + arg + '"')
			printHelp(1)

#Double check to make sure that the opcode directory and malware type file are valid
if not os.path.isdir(opcodeFolder):
	print('ERROR: "' + opcodeFolder + '" is not a directory')
	printHelp(1)
if malwareTypesFile != None and not os.path.isfile(malwareTypesFile):
	print('ERROR: "' + malwareTypesFile + '" is not a file')
	printHelp(1)

print("Starting")

#Walk through opcode directory and save the full file paths of valid .opcode files
opcodeFiles = []
for folder in os.listdir(opcodeFolder):
	for file in os.listdir(os.path.join(opcodeFolder, folder)):
		filename = os.path.join(opcodeFolder, folder, file)

		#If the file is too small it is likely not a valid sample, so skip it
		if os.path.getsize(filename) < MIN_VALID_FILE_SIZE:
			continue

		opcodeFiles.append(filename)

#Preprocessing function passed to the vectorizer. This will remove all operands and split opcodes using spaces
def pre(s):
	return " ".join([ line.split(" ")[0] for line in s.split("\n") ])

#Set up the vectorizer
vectorizer = TfidfVectorizer(input = "filename", preprocessor = pre, ngram_range = ngram)

print("Setup done, vectorizing files now")

#Vectorize the opcode files
X = vectorizer.fit_transform(opcodeFiles)
Xarr = X.toarray()
featureNamesStr = ",".join(vectorizer.get_feature_names_out())

#Create a dict of hash:type from the malware type file
if malwareTypesFile == None:
	typesDict = {}
else:
	with open(malwareTypesFile, "r") as f:
		typesDict = dict([ [i.strip() for i in line.split(",")] for line in f.readlines() ])

print("Vectorizing done, writing output to csv file now")

#Create the output .csv file based on the vectorized opcode counts, malware types, and APT groups
with open(processedDataFile, "w+") as f:
	f.write("Filename,Malware Type,APT Group," + featureNamesStr + "\n")
	for index in range(len(opcodeFiles)):
		filepath = opcodeFiles[index]
		path, filename = os.path.split(filepath)
		aptGroup = os.path.basename(path)
		hash = os.path.splitext(filename)[0]
		type = typesDict.get(hash, DEFAULT_MALWARE_TYPE)
		Xvals = ",".join([ str(i) for i in Xarr[index] ])
		f.write(hash + "," + type + "," + aptGroup + "," + Xvals + "\n")

print("All done")