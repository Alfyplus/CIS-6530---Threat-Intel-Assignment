#Written by Victor Vezina and Alfred Amoah for CIS*6530 Submission 4

import os
import sys
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

#Define global constants
INVALID_CATEGORIES = ["Unknown", "Unassigned"]
HELP_INFO = '''Valid Arguments:
-i/--input <csv_paths> to set the paths to one or more input csv files, as comma seperated values (Required)
-m/--model <model> to set the ML algorithm to use. Valid values are: (k)nn, (d)ecision_tree, (s)vm, or (a)ll (Default all)
-c/--combined <combined> to set if combined models should be analysed using consensus. Either (t)rue or (f)alse (Default true)
-t/--type <category_type> to set the category to train the model on. Either (t)ype or (g)roup (Default type)
-s/--state <random_state> to set the random_state value used in certain models (Default random)
-n/--neighbors <n_neighbors> to set the number of neighbors used for the k-NN algorithm (Default 4)
-o/--output <output_string> to enable different outputs. The string can contain the following characters: p for accuracy, recall, precision, and f1 score printouts, g to plot the scores graph, m for confusion matrix plot, n for no output (Default pgm)'''

#Define global variables and their defaults
csvFiles = []
models = ["k-NN", "Decision Tree", "SVM"]
combined = True
categoryIndex = 1
state = None
numNeighbors = 4
outputArr = [True, True, True]

#Print help information and exit the program
def printHelp(code = 0):
	print(HELP_INFO)
	exit(code)

#Parse command line arguments
if len(sys.argv) >= 2:
	def getArg(index, arg):
		if index+1 >= len(sys.argv):
			print('ERROR: No value found after argument "' + arg + '"')
			printHelp(1)
		else:
			return sys.argv[index+1]

	index = 1
	while index < len(sys.argv):
		arg = sys.argv[index].strip()
		if arg == "-h" or arg == "--help":
			printHelp()
		elif arg == "-i" or arg == "--input":
			#Set the csv files based on given input, splitting the string on commas
			csvFilesStr = getArg(index, arg)
			for csvFileStr in csvFilesStr.split(","):
				csvFile = os.path.abspath(csvFileStr.strip())

				#Ensure that each csv path is a valid file
				if not os.path.isfile(csvFile):
					print('ERROR: "' + csvFile + '" is not a file')
					printHelp(1)
				csvFiles.append(csvFile)
			print('Set input csv files to "' + str(csvFiles) + '"')
			index += 2
		elif arg == "-m" or arg == "--model":
			#Set the model(s) to be used based on given input. There a many valid arguments for each model to ensure maximum usability
			modelStr = getArg(index, arg).lower().strip()
			if modelStr in ["k", "knn", "k-nn", "neighbour", "neighbours"]:
				models = ["k-NN"]
			elif modelStr in ["d", "decision_tree", "decision", "tree"]:
				models = ["Decision Tree"]
			elif modelStr in ["s", "svm", "svc", "vector"]:
				models = ["SVM"]
			elif modelStr in ["a", "all"]:
				models = ["k-NN", "Decision Tree", "SVM"]
			else:
				print('ERROR: Unknown model "' + modelStr + '"')
				printHelp(1)
			print('Set model to ' + modelStr)
			index += 2
		elif arg == "-c" or arg == "--combined":
			#Set if combined models should be used based on given input. There a many valid arguments for both options to ensure maximum usability
			comStr = getArg(index, arg).lower().strip()
			if comStr in ["t", "true", "y", "yes"]:
				combined = True
			elif comStr in ["f", "false", "n", "no"]:
				combined = False
			else:
				print('ERROR: Unknown combined value "' + comStr + '"')
				printHelp(1)
			print('Set combined to ' + comStr)
			index += 2
		elif arg == "-t" or arg == "--type":
			#Set the category that should be used based on given input. There a many valid arguments for both options to ensure maximum usability
			catStr = getArg(index, arg).lower().strip()
			if catStr in ["t", "type", "malware_type", "1"]:
				categoryIndex = 1
			elif catStr in ["g", "group", "apt", "apt_group", "2"]:
				categoryIndex = 2
			else:
				print('ERROR: Unknown category_type "' + catStr + '"')
				printHelp(1)
			print('Set category_type to ' + catStr)
			index += 2
		elif arg == "-s" or arg == "--state":
			#Set the state value based on given input
			state = int(getArg(index, arg).strip())
			print('Set random_state to ' + str(state))
			index += 2
		elif arg == "-n" or arg == "--neighbors":
			#Set the number of neighbours to use in KNN based on given input. Ensures that the number is between 3 and 5
			numNeighbors = int(getArg(index, arg).strip())
			if numNeighbors < 3 or numNeighbors > 5:
				print('ERROR: n_neighbors must be between 3 and 5')
				printHelp(1)
			print('Set n_neighbors to ' + str(numNeighbors))
			index += 2
		elif arg == "-o" or arg == "--output":
			#Set which outputs should be generated based on given input. This is a pretty ugly way to do this
			outputStr = getArg(index, arg).lower().strip()
			outputArr = [False, False, False]
			for char in outputStr:
				if char == "p":
					outputArr[0] = True
				elif char == "g":
					outputArr[1] = True
				elif char == "m":
					outputArr[2] = True
				elif char == "n":
					outputArr = [False, False, False]
					break
				else:
					print('ERROR: Unknown output_string character "' + char + '"')
					printHelp(1)
			print('Set output_string to ' + outputStr)
			index += 2
		else:
			print('ERROR: Unknown argument "' + arg + '"')
			printHelp(1)

#Ensure that at least one csv file path has been given
if csvFiles == None or len(csvFiles) == 0:
	print('ERROR: csv input files not specified')
	printHelp(1)

#Ensure that each given csv path is a valid file
for csvFile in csvFiles:
	if not os.path.isfile(csvFile):
		print('ERROR: "' + csvFile + '" is not a file')
		printHelp(1)

#Helper function to print the outputs needed (score printout and confusion matrix) based on given category predictions and correct category values
def outputPredictions(outputStr, categories, catPrediction, extraPrint = False):
	#Create and return a list of calculated scores, used to create the score graph at the end
	scores = []
	scores.append(accuracy_score(categories, catPrediction))
	scores.append(recall_score(categories, catPrediction, average="macro", zero_division=0))
	scores.append(precision_score(categories, catPrediction, average="macro", zero_division=0))
	scores.append(f1_score(categories, catPrediction, average="macro", zero_division=0))

	#If score printout is desired
	if outputArr[0]:
		if extraPrint:
			print()
		print(outputStr + " accuracy: " + str(scores[0]))
		print(outputStr + " recall (macro): " + str(scores[1]))
		print(outputStr + " precision (macro): " + str(scores[2]))
		print(outputStr + " f1 score (macro): " + str(scores[3]))

	#If confusion matrix is desired
	if outputArr[2]:
		ConfusionMatrixDisplay(confusion_matrix(categories, catPrediction), display_labels=categoryLabels).plot(cmap=None, values_format="d")
		plt.tick_params(axis = "x", labelrotation = 90)
		plt.title("Confusion Matrix for " + outputStr)

		#Don't block execution when showing the matrix, but briefly pause it to ensure the matrix is shown correctly
		plt.show(block=False)
		plt.pause(0.5)

	return scores

#Go through each csv file seperately
combinedPredsAll = []
categoryLabels = None
scoresArr = []
for csvIndex in range(len(csvFiles)):
	csvFile = csvFiles[csvIndex]
	if csvIndex > 0:
		print()
	print('Starting analysis of file "' + csvFile + '"')

	with open(csvFile, "r") as f:
		lines = f.readlines()

	#Read and parse the data from the csv file, including malware type or apt group based on the set category index value
	categories = []
	data = []
	for line in lines[1:]:
		lineSplit = line.split(",")
		catVal = lineSplit[categoryIndex].strip()
		if catVal in INVALID_CATEGORIES:
			continue

		currData = [ float(val.strip()) for val in lineSplit[3:] ]
		categories.append(catVal)
		data.append(currData)

	#Set the output string for pretty printing
	if "1-gram" in csvFile.lower() or "1gram" in csvFile.lower():
		outputFileStr = "1-gram "
	elif "2-gram" in csvFile.lower() or "2gram" in csvFile.lower():
		outputFileStr = "2-gram "
	else:
		outputFileStr = ""

	#Train each model seperately
	combinedPredsModels = []
	for modelIndex in range(len(models)):
		modelStr = models[modelIndex]

		#Set the model based on the current modelStr
		if modelStr == "k-NN":
			model = Pipeline(steps=[ ("scaler", StandardScaler()), ("clf", KNeighborsClassifier(n_neighbors=numNeighbors)) ])
		elif modelStr == "Decision Tree":
			if state != None:
				model = Pipeline(steps=[ ("scaler", StandardScaler()), ("clf", DecisionTreeClassifier(random_state = state)) ])
			else:
				model = Pipeline(steps=[ ("scaler", StandardScaler()), ("clf", DecisionTreeClassifier()) ])
		elif modelStr == "SVM":
			if state != None:
				model = Pipeline(steps=[ ("scaler", StandardScaler()), ("clf", SVC(kernel="linear", random_state = state)) ])
			else:
				model = Pipeline(steps=[ ("scaler", StandardScaler()), ("clf", SVC(kernel="linear")) ])
		else:
			print('INTERNAL ERROR: Unknown model type "' + modelStr + '"')
			exit(1)

		#Predict the category of each sample using Leave One Out Cross-Validation
		catPrediction = cross_val_predict(model, data, categories, cv = LeaveOneOut())

		#Add these predictions to the array used for the combination model
		combinedPredsModels.append([modelStr, catPrediction])

		#Set the categoryLabels variable, used for pretty printing
		if categoryLabels is None:
			model.fit(data, categories)
			categoryLabels = model.classes_

		#Output the desired values to the user and save the calculated scores for use in the score graph
		scores = outputPredictions(outputFileStr + modelStr, categories, catPrediction, modelIndex > 0)
		scoresArr.append([outputFileStr + modelStr, scores])

	#If we are creating combined models, create one for all the models trained on the data from this csv file
	if combined and len(models) > 1:
		#Add the combined predictions to the array used for the All Combined model
		combinedPredsAll.append([csvFile, categories, combinedPredsModels])

		#For each sample, calculate the consensus category prediction made by the models
		catPrediction = []
		for dataIndex in range(len(combinedPredsModels[0][1])):
			#Create a dict of category:count for the predicted categories
			catPreds = {}
			for modelIndex in range(len(combinedPredsModels)):
				currPred = combinedPredsModels[modelIndex][1][dataIndex]
				catPreds[currPred] = 1 + catPreds.get(currPred, 0)

			#Find which category was predicted most
			#For ties this simply takes the first one, not ideal but tie breaking is a complicated problem to solve
			best = [None, 0]
			for category, amount in catPreds.items():
				if amount > best[1]:
					best = [category, amount]
			catPrediction.append(best[0])

		#Output the desired values to the user and save the calculated scores for use in the score graph
		scores = outputPredictions(outputFileStr + "Combined", categories, catPrediction, True)
		scoresArr.append([outputFileStr + "Combined", scores])
	elif combined:
		#If we are creating combined models, but this csv file used only one model we don't create a combined model for this csv file
		#Add the combined predictions to the array used for the All Combined model
		combinedPredsAll.append([csvFile, categories, combinedPredsModels])

#If we are creating combined models, create one for all models
if combined and len(csvFiles) > 1:
	#For each sample, calculate the consensus category prediction made by the models
	catPrediction = []
	categories = combinedPredsAll[0][1]
	for dataIndex in range(len(combinedPredsAll[0][2][0][1])):
		#Create a dict of category:count for the predicted categories
		catPreds = {}
		for csvIndex in range(len(combinedPredsAll)):
			#Ensure that the categories are consistent across all csv files
			if categories != combinedPredsAll[csvIndex][1]:
				print('ERROR: Category mismatch in combined data')
				exit(1)
			for modelIndex in range(len(combinedPredsAll[csvIndex][2])):
				currPred = combinedPredsAll[csvIndex][2][modelIndex][1][dataIndex]
				catPreds[currPred] = 1 + catPreds.get(currPred, 0)

		#Find which category was predicted most
		#For ties this simply takes the first one, not ideal but tie breaking is a complicated problem to solve
		best = [None, 0]
		for category, amount in catPreds.items():
			if amount > best[1]:
				best = [category, amount]
		catPrediction.append(best[0])

	#Output the desired values to the user and save the calculated scores for use in the score graph
	scores = outputPredictions("All Combined", categories, catPrediction, True)
	scoresArr.append(["All Combined", scores])

#If score graph output is desired, create it
if outputArr[1]:
	fig, ax = plt.subplots()
	x = [1, 2, 3, 4]

	#Calculate the width of each bar based on the number of models being evaluated
	width = 1.0 / (len(scoresArr) + 2)

	#For each model, graph its scores with a given offset from the x-axis ticks
	for scoreIndex in range(len(scoresArr)):
		scores = scoresArr[scoreIndex]
		multiplier = 1 - len(scoresArr) + 2 * scoreIndex
		ax.bar([i + multiplier*(width/2) for i in x], scores[1], width, label=scores[0])

	#Set labels and titles for the bar graph
	ax.set_xticks(x)
	ax.set_xticklabels(["Accuracy", "Recall (macro)", "Precision (macro)", "f1 score (macro)"])
	ax.set_xlim(0.5, 4.5)
	ax.legend(ncol=2)
	if categoryIndex == 1:
		ax.set_title("Scores For Malware Type Classification By Model And N-gram")
	else:
		ax.set_title("Scores For APT Group Classification By Model And N-gram")
	fig.tight_layout()
	plt.show()

print("\nAll analysis done")

#Final blocking plot show to ensure users can look at displayed confusion matrices
plt.show()